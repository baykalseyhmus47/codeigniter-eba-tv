<?php 
function get_readable_date($date)
{
    return strftime('%d.%m.%Y', strtotime($date));
}
?>