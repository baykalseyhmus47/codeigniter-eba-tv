<!DOCTYPE html>
<html lang="tr">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Eba Tv</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>

<body>
	<div class="container">
		<div class="row">
			<h1 style="padding: 30px">
				<?php
				$getdate = time() + (7 * 24 * 60 * 60);
				echo 'EBA TV DERS PROGRAMI:         ' . date('d/m/Y') . "\n";
				?>
			</h1>
			<table class="table table-bordered table-striped table-hover">
				<thead class="thead-dark ">
					<tr>
						<th scope="col">Saat</th>
						<th scope="col">Dersin Adı</th>
						<th scope="col">Konu</th>
						<th scope="col">Sınıf</th>
						<th scope="col">Tarih</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($ebatvdata as $hd) { ?>
						<tr>
							<td><?php echo $hd['hour']; ?></td>
							<td><?php echo $hd['title']; ?></td>
							<td><?php echo $hd['subject']; ?></td>
							<td><?php echo $hd['classLevel']; ?></td>
							<td><?php echo get_readable_date($hd['day']); ?></td>
						</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>

</html>