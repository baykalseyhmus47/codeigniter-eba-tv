<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Ebatv extends CI_Controller
{

	public function index()
	{
		$viewData = new stdClass();
		$this->load->library('eba');
		$this->load->helper('eba');
		$viewData->ebatvdata		= $this->eba->ebatvdata();
		$this->load->view('ebatv', $viewData);
	}
}
