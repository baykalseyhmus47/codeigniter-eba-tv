<?php
class Eba
{
    function ebatvdata()
     {
        $ch = curl_init();
        curl_setopt_array(
            $ch,
            [
                CURLOPT_URL => 'https://onyuzyonetim.eba.gov.tr/api/show/plans/daily?date=2020-04-24&classType=ilkokul',
                CURLOPT_RETURNTRANSFER => true
            ]
        );
        $getdata = curl_exec($ch);
        curl_close($ch);
        $getdata = json_decode($getdata, true);
        return  $getdata;
     }
}
